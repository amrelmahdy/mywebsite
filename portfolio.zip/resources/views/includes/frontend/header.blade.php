<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Amr El-Mahdy | @yield('title') </title>

<!-- Bootstrap -->
{!! Html::style('css/common/app.css') !!}
{!! Html::style('css/common/font-awesome.css') !!}
{!! Html::style('css/frontend/main.css') !!}
{!! Html::style('css/frontend/media.css') !!}
@yield('styles')

@yield('extrastyles')
