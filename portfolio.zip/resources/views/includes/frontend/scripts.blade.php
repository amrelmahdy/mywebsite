
<!-- Bootstrap and JQuiry -->
{!! Html::script('js/common/app.js') !!}

<!-- Mix it up -->
{!! Html::script('js/frontend/jquery.mixitup.min.js') !!}

<!-- Main script -->
{!! Html::script('js/frontend/main.js') !!}

@yield('scripts')