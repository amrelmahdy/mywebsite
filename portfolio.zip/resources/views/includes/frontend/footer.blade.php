<section class="footer text-center">
	<p>&copy; {{ date('Y') }}  All Rights Reserved to Amr El Mahdy.</p>
	<i class="fa fa-angle-up fa-2x"></i>
</section>

@include('includes.frontend.scripts')