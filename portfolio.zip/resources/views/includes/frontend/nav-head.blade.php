@section('head')
  @include('includes.frontend.navbar')
@show