
<!-- Bootstrap and JQuiry -->
{!! Html::script('js/common/app.js') !!}

<script>
    $('#page-content-wrapper').animate({
        'float' : 'right',
        'width' : '80%' 
    });
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
        if($(window).width() > 768){
            if($("#wrapper").hasClass('toggled')){
            	$('#page-content-wrapper').animate({
    	        	'float' : 'none',
    	        	'width' : '100%' 
                });
            } else {
            	$('#page-content-wrapper').animate({
    	        	'float' : 'right',
    	        	'width' : '80%' 
                });
            }
        }
    });
</script>

<!-- Main script -->
{!! Html::script('js/admin/main.js') !!}

@yield('scripts')