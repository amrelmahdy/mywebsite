<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Admin Area | @yield('title') </title>

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">

<!-- Bootstrap -->
{!! Html::style('css/common/app.css') !!}
{!! Html::style('css/common/font-awesome.css') !!}
{!! Html::style('css/admin/simple-sidebar.css') !!}
{!! Html::style('css/admin/navbar.css') !!}
{!! Html::style('css/admin/main.css') !!}

@yield('styles')

@yield('extrastyles')
