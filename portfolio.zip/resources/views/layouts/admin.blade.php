<!DOCTYPE html>
<html lang="en">
  <head>

    @include('includes.admin.header')
    
  </head>

  <body>  
     @include('includes.admin.navbar')
     <div id="wrapper">
        @include('includes.admin.sidebar')
        <!-- Page Content -->
        <div id="page-content-wrapper">
        
           @include('includes.admin.infobox')

           @yield('content')
                  
        </div>

    </div>
    
      
     @include('includes.admin.footer')
  </body>
</html>