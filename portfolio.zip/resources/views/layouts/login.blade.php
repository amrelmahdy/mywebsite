<!DOCTYPE html>
<html lang="en">
  <head>

    @include('includes.admin.header')
    
  </head>

  <body>  
     @if(count($errors) > 0)
         <div class="error-info">
         	  @foreach($errors->all() as $error)
         	    {{ $error }}
         	  @endforeach
          </div>
     @endif

     @yield('content')
      
     @include('includes.admin.scripts')
  </body>
</html>