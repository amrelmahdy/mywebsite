@extends('layouts.login')

@section('title', 'Admin login')

@section('styles')
   {!! Html::style('css/admin/login.css') !!}
   <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
@stop

@section('content')
   <div class="container">
        <div class="login-container">
            <div id="output"></div>
            <div class="form-box">
                <h1>Admin Login</h1>
                
                {!! Form::open(['route' => 'login']) !!}
                    {{ Form::text('email', null, ['class' => 'form-control', 'placeholder' => 'Username or Email']) }}
                    {{ Form::password('password', ['class' => 'form-control', 'placeholder' => 'Password']) }}

                    {{ Form::submit('Login', ['class' => 'btn btn-block btn-lg']) }}
                {!! Form::close() !!}

                {{ Html::linkRoute('forgot-password', 'Forgot Password',  [], ['class' => 'forgot-password']) }}

            </div>
        </div>
    </div>
@stop