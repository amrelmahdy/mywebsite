@extends('layouts.admin')

@section('title', 'Skills')

@section('content')
  <div class="row">
      <div class="col-md-12">
          <h1>Skills</h1>
          <hr>
      </div>
  </div>

  <div class="row">
  	<div class="col-md-8">
  		<div class="table-responsive">
  			<table class="table">
  				<thead>
  				    <tr>
	  					<th>ID</th>
	  					<th>Skill</th>
	  					<th>Percentage</th>
	  					<th>Status</th>
	  					<th class="text-center">Action</th>
  					</tr>
  				</thead>
  				<tbody>
  					@foreach($skills as $skill)
  					   <tr>
  					   	  <td>{{ $skill->id }}</td>
  					   	  <td>{{ $skill->skill }}</td>
  					   	  <td>{{ $skill->percentage }}</td>
  					   	  <td> {{ $skill->viewed == true ? 'Viewed' : 'Hidden'}}</td>
  					   	  <td class="text-center">
  					   	  	<a href="" class="btn btn-xs">
  					   	  		<i class="fa fa-eye fa-fw"></i>
  					   	  	</a>

  					   	  	<a href="" class="btn btn-xs">
  					   	  		<i class="fa fa-edit fa-fw"></i>
  					   	  	</a>

  					   	  	<a href="" class="btn btn-xs">
  					   	  		<i class="fa fa-trash fa-fw"></i>
  					   	  	</a>
  					   	  </td>
  					   </tr>
  					@endforeach
  				</tbody>
  			</table>
  		</div>
  	</div>

    <div class="col-md-4">
      <div class="well">
        <h2 class="text-center">Add Skill</h2>
        {{ Form::open(['class' => 'form']) }}
           {{ Form::label('skill', 'Skill') }}
           {{ Form::text('skill', null, ['class' => 'form-control', 'placeholder' => 'skill']) }}

           {{ Form::label('percentage', 'Percentage') }}
           <input type="range" name="percentage" min="0" max="100" value="0">
           
           {{ Form::label('viewed', 'Visability') }}
           {{ Form::select('viewed', ['Viewed', 'Hidden'], null, ['class' => 'form-control', 'placeholder' => 'Visability']) }}
           {{ Form::submit('Add', ['class' => 'btn btn-spec btn-block']) }}
        {{ Form::close() }}
      </div>
      <p class="text-center"><b>Only 7 skill will be visable on frontend</b></p>
    </div>

  </div>
@stop