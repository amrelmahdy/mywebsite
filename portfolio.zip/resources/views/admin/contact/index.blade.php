@extends('layouts.admin')

@section('title', 'Skills')

@section('content')
  <div class="row">
      <div class="col-md-10">
          <h1>Skills</h1>
      </div>

      <div class="col-md-2">
      	<a href="" class="btn btn-spec btn-block">Add</a>
      </div>
  </div>

  <div class="row">
  	<div class="col-md-12">
  		<div class="table-responsive">
  			<table class="table">
  				<thead>
  				    <tr>
	  					<th>ID</th>
	  					<th>Skill</th>
	  					<th>Percentage</th>
	  					<th>Status</th>
	  					<th class="text-center">Action</th>
  					</tr>
  				</thead>
  				<tbody>
  					@foreach($skills as $skill)
  					   <tr>
  					   	  <td>{{ $skill->id }}</td>
  					   	  <td>{{ $skill->skill }}</td>
  					   	  <td>{{ $skill->percentage }}</td>
  					   	  <td> {{ $skill->viewed == true ? 'Viewed' : 'Hidden'}}</td>
  					   	  <td class="text-center">
  					   	  	<a href="" class="btn btn-xs">
  					   	  		<i class="fa fa-eye fa-fw"></i>
  					   	  	</a>

  					   	  	<a href="" class="btn btn-xs">
  					   	  		<i class="fa fa-edit fa-fw"></i>
  					   	  	</a>

  					   	  	<a href="" class="btn btn-xs">
  					   	  		<i class="fa fa-trash fa-fw"></i>
  					   	  	</a>
  					   	  </td>
  					   </tr>
  					@endforeach
  				</tbody>
  			</table>
  		</div>
  	</div>
  </div>
@stop