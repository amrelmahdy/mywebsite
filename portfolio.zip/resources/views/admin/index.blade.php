@extends('layouts.admin')

@section('title', 'Homepage')


@section('content')
   <div class="jumbotron text-center">
	  <h1 class="display-3">Amr El Mahdy Admin Area</h1>
	  <p>Here you can manage all items on amrelmahdy.com</p> 
	  <a class="btn btn-primary btn-lg" href="http://amrelmahdy.com" role="button">FRONTEND</a>
   </div>
@stop