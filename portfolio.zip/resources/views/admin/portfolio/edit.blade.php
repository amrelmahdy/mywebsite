@extends('layouts.admin')

@section('title', 'Edit sample')

@section('content')
  <div class="row">
      <div class="col-md-12">
          <h1 class="text-center">Edit sample</h1>
          <hr>
      </div>
  </div>

  <div class="row">
    <div class="col-md-6 col-md-offset-3">
        {!! Form::model($sample, ['route' => ['portfolio.update', $sample->id], 'method' => 'put', 'class' => 'form', 'files' => true]) !!}
           
          {{ Form::label('project_name', 'Project Name') }}
          {{ Form::text('project_name', null, ['class' => $errors->has('project_name') ? 'form-control required' : 'form-control' , 'placeholder' => 'Project Name']) }}
          <span class="error">{{ $errors->has('project_name') ? $errors->first('project_name') : '' }}</span>
          

          {{ Form::label('category_id', 'Category') }}
          {{ Form::select('category_id', $cats, null, ['class' => $errors->has('project_name') ? 'form-control required' : 'form-control' , 'placeholder' => 'Project Name']) }}
          <span class="error">{{ $errors->has('category_id') ? $errors->first('category_id') : '' }}</span>
    
          {{ Form::label('image', 'Image') }}
          {{ Form::file('image', ['class' => $errors->has('image') ? 'form-control required' : 'form-control' , 'placeholder' => 'Project Name']) }}
          <span class="error">{{ $errors->has('image') ? $errors->first('image') : '' }}</span>

          

          {{ Form::label('link', 'Link') }}
          {{ Form::text('link', null, ['class' => $errors->has('link') ? 'form-control required' : 'form-control', 'placeholder' => 'Sample\'s Link']) }}
          <span class="error">{{ $errors->has('link') ? $errors->first('link') : '' }}</span>

          {{ Form::label('description', 'Description') }}
          {{ Form::textarea('description', null, ['class' => $errors->has('description') ? 'form-control required' : 'form-control', 'rows' => '3', 'placeholder' => 'Description']) }}
          <span class="error">{{ $errors->has('description') ? $errors->first('description') : '' }}</span>

          {{ Form::submit('Update', ['class' => 'btn btn-spec btn-block']) }}
    </div>
  </div>
@stop