@extends('layouts.admin')

@section('title', 'Portfolio')

@section('content')
  <div class="row">
      <div class="col-md-11">
          <h1>Portfolio</h1>
      </div>

      <div class="col-md-1">
      	<a href="{{ route('portfolio.create') }}" class="btn btn-spec">Add</a>
      </div>

      <div class="col-md-12">
        <hr>
      </div>
  </div>


   @foreach($samples as $sample)
     <div class="row samples">
       <div class="col-md-4 sample">
         <div class="overlay">
           <a href="{{ route('portfolio.edit', $sample->id) }}" class="btn-spec-trans btn-over">Edit</a>
         </div>
         <img src="{{ asset('images/portfolio/' . $sample->image ) }}" alt="">
       </div>

       <div class="col-md-8">
         <div class="sample-desc">
             <ul>
                <li><span>Project Name : </span>{{ $sample->project_name }}</li>
                <li><span>Category : </span>{{ $sample->category->filter_name }}</li>
                <li><span>Description : </span>{{ $sample->description }}</li>
                <a href="{{ $sample->link}}" class="btn btn-spec btn-sm">Visit</a>
                <a href="{{ route('portfolio.edit', $sample->id) }}" class="btn btn-spec-primary btn-sm">Edit</a>
                <a href="{{ $sample->link}}" class="btn btn-spec-danger btn-sm">Delete</a>
             </ul>
         </div>
       </div>
     </div>
     <hr>
   @endforeach

  	
@stop