<?php $__env->startSection('title', 'Portfolio'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
      <div class="col-md-11">
          <h1>Portfolio</h1>
      </div>

      <div class="col-md-1">
      	<a href="<?php echo e(route('portfolio.create')); ?>" class="btn btn-spec">Add</a>
      </div>

      <div class="col-md-12">
        <hr>
      </div>
  </div>


   <?php $__currentLoopData = $samples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sample): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
     <div class="row samples">
       <div class="col-md-4 sample">
         <div class="overlay">
           <a href="<?php echo e(route('portfolio.edit', $sample->id)); ?>" class="btn-spec-trans btn-over">Edit</a>
         </div>
         <img src="<?php echo e(asset('images/portfolio/' . $sample->image )); ?>" alt="">
       </div>

       <div class="col-md-8">
         <div class="sample-desc">
             <ul>
                <li><span>Project Name : </span><?php echo e($sample->project_name); ?></li>
                <li><span>Category : </span><?php echo e($sample->category->filter_name); ?></li>
                <li><span>Description : </span><?php echo e($sample->description); ?></li>
                <a href="<?php echo e($sample->link); ?>" class="btn btn-spec btn-sm">Visit</a>
                <a href="<?php echo e(route('portfolio.edit', $sample->id)); ?>" class="btn btn-spec-primary btn-sm">Edit</a>
                <a href="<?php echo e($sample->link); ?>" class="btn btn-spec-danger btn-sm">Delete</a>
             </ul>
         </div>
       </div>
     </div>
     <hr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

  	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>