<?php $__env->startSection('title', 'Homepage'); ?>


<?php $__env->startSection('content'); ?>
   <div class="jumbotron text-center">
	  <h1 class="display-3">Amr El Mahdy Admin Area</h1>
	  <p>Here you can manage all items on amrelmahdy.com</p> 
	  <a class="btn btn-primary btn-lg" href="http://amrelmahdy.com" role="button">FRONTEND</a>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>