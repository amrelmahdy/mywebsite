<?php $__env->startSection('title', 'Admin login'); ?>

<?php $__env->startSection('styles'); ?>
   <?php echo Html::style('css/admin/login.css'); ?>

   <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="container">
        <div class="login-container">
            <div id="output"></div>
            <div class="form-box">
                <h1>Admin Login</h1>
                
                <?php echo Form::open(['route' => 'login']); ?>

                    <?php echo e(Form::text('email', null, ['class' => 'form-control', 'placeholder' => 'Username or Email'])); ?>

                    <?php echo e(Form::password('password', ['class' => 'form-control', 'placeholder' => 'Password'])); ?>


                    <?php echo e(Form::submit('Login', ['class' => 'btn btn-block btn-lg'])); ?>

                <?php echo Form::close(); ?>


                <?php echo e(Html::linkRoute('forgot-password', 'Forgot Password',  [], ['class' => 'forgot-password'])); ?>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>