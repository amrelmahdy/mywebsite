<?php $__env->startSection('title', 'Create sample'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
      <div class="col-md-12">
          <h1 class="text-center">Create sample</h1>
          <hr>
      </div>
  </div>

  <div class="row">
    <div class="col-md-6 col-md-offset-3">
        <?php echo Form::open(['route' => 'portfolio.store', 'class' => 'form', 'files' => true]); ?>

          
          
          <?php echo e(Form::label('project_name', 'Project Name')); ?>

          <?php echo e(Form::text('project_name', null, ['class' => $errors->has('project_name') ? 'form-control required' : 'form-control' , 'placeholder' => 'Project Name'])); ?>

          <span class="error"><?php echo e($errors->has('project_name') ? $errors->first('project_name') : ''); ?></span>
          

          <?php echo e(Form::label('category_id', 'Category')); ?>

          <?php echo e(Form::select('category_id', $cats, null, ['class' => $errors->has('project_name') ? 'form-control required' : 'form-control' , 'placeholder' => 'Project Name'])); ?>

          <span class="error"><?php echo e($errors->has('category_id') ? $errors->first('category_id') : ''); ?></span>
    
          <?php echo e(Form::label('image', 'Image')); ?>

          <?php echo e(Form::file('image', ['class' => $errors->has('image') ? 'form-control required' : 'form-control' , 'placeholder' => 'Project Name'])); ?>

          <span class="error"><?php echo e($errors->has('image') ? $errors->first('image') : ''); ?></span>

          

          <?php echo e(Form::label('link', 'Link')); ?>

          <?php echo e(Form::text('link', null, ['class' => $errors->has('link') ? 'form-control required' : 'form-control', 'placeholder' => 'Sample\'s Link'])); ?>

          <span class="error"><?php echo e($errors->has('link') ? $errors->first('link') : ''); ?></span>

          <?php echo e(Form::label('description', 'Description')); ?>

          <?php echo e(Form::textarea('description', null, ['class' => $errors->has('description') ? 'form-control required' : 'form-control', 'rows' => '3', 'placeholder' => 'Description'])); ?>

          <span class="error"><?php echo e($errors->has('description') ? $errors->first('description') : ''); ?></span>

          <?php echo e(Form::submit('Update', ['class' => 'btn btn-spec btn-block'])); ?>

        <?php echo Form::close(); ?>

    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>