<?php if(Session::has('success')): ?>
   <div class="success-msg"><?php echo e(Session::get('success')); ?></div>
<?php endif; ?>

<?php if(Session::has('status')): ?>
   <div class="success-msg"><?php echo e(Session::get('status')); ?></div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
   <div class="error-msg"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>