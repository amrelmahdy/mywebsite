
<!-- Bootstrap and JQuiry -->
<?php echo Html::script('js/common/app.js'); ?>


<!-- Mix it up -->
<?php echo Html::script('js/frontend/jquery.mixitup.min.js'); ?>


<!-- Main script -->
<?php echo Html::script('js/frontend/main.js'); ?>


<?php echo $__env->yieldContent('scripts'); ?>