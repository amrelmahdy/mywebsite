<section class="footer text-center">
	<p>&copy; <?php echo e(date('Y')); ?>  All Rights Reserved to Amr El Mahdy.</p>
	<i class="fa fa-angle-up fa-2x"></i>
</section>

<?php echo $__env->make('includes.frontend.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>