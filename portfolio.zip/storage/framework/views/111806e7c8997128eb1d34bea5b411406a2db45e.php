<!-- Sidebar -->


<div id="sidebar-wrapper">

    <ul class="sidebar-nav">
        <li class="sidebar-brand">
            <a href="/admin">
                Amr Dashboard
            </a>
        </li>
        <li <?php echo e(Request::is('admin') ? 'class=active' : ''); ?>>
            <a href="/admin">Home</a>
            <a href="/admin"><i class="fa fa-home fa-lg fa-fw pull-right"></i></a>
        </li>
        <li>
            <a href="#">Qoutes</a>
            <i class="fa fa-sign-in fa-fw fa-lg pull-right"></i>
        </li>
        <li>
            <a href="#">Contact info</a>
            <i class="fa fa-envelope fa-fw fa-lg pull-right"></i>
        </li>
        <li>
            <a href="#">Statistics</a>
            <i class="fa fa-bar-chart-o fa-fw fa-lg pull-right"></i>
        </li>
        <li>
            <a href="#">Profile image</a>
            <i class="fa fa-image fa-fw fa-lg pull-right"></i>
        </li>
        <li <?php echo e(Request::is('admin/skills') ? 'class=active' : ''); ?>>
            <a href="<?php echo e(route('skills')); ?>">Skills</a>
            <i class="fa fa-server fa-fw fa-lg pull-right"></i>
        </li>
        <li>
            <a href="#">Services</a>
            <i class="fa fa-suitcase fa-fw fa-lg pull-right"></i>
        </li>
        <li>
            <a href="#">Education</a>
            <i class="fa fa-graduation-cap fa-fw fa-lg pull-right"></i>
        </li>
        <li>
            <a href="#">Experience</a>
            <i class="fa fa-briefcase fa-fw fa-lg pull-right"></i>
        </li>
        <li>
            <a href="#">Social network</a>
            <i class="fa fa-share-square fa-fw fa-lg pull-right"></i>
        </li>
        
        <li <?php echo e(Request::is('admin/portfolio*') ? 'class=active' : ''); ?>>
            <a href="<?php echo e(route('portfolio')); ?>">Portfolio</a>
            <a href="<?php echo e(route('portfolio')); ?>"><i class="fa fa-laptop fa-fw fa-lg pull-right"></i></a>

        </li>
        <li>
            <a href="#">Resume</a>
            <i class="fa fa-file fa-fw fa-lg pull-right"></i>
        </li>
        <li>
            <a href="#">Location</a>
            <i class="fa fa-map-marker fa-fw fa-lg pull-right"></i>
        </li>
    </ul>
</div>
<!-- /#sidebar-wrapper -->