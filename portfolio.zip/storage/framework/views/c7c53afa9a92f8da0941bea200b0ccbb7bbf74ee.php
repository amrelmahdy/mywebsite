<?php $__env->startSection('styles'); ?>
   <?php $__env->startSection('styles'); ?>
   <?php echo Html::style('css/admin/login.css'); ?>

   <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
           <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-default email-reset-form">
                  <div class="panel-heading">
                    <h1 class="text-center reset-email">Forgot Password</h1>
                  </div> 
                  <div class="panel-body"> 
                    <?php echo Form::open(['url' => '/admin/password/email', 'method' => 'POST', 'class' => 'form']); ?>


                        <?php echo e(Form::label('email', 'Email')); ?>

                        <?php echo e(Form::text('email', null, ['class' => 'form-control', 'placeholder' => 'Your Email '])); ?>

                        
                        <?php echo e(Form::submit('Send Confirmation Email', ['class' => 'btn btn-primary'])); ?>

                    
                    <?php echo Form::close(); ?>

                  </div>
                </div>
           </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>