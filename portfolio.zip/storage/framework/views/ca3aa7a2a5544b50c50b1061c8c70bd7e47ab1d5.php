<?php $__env->startSection('title', 'Skills'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
      <div class="col-md-12">
          <h1>Skills</h1>
          <hr>
      </div>
  </div>

  <div class="row">
  	<div class="col-md-8">
  		<div class="table-responsive">
  			<table class="table">
  				<thead>
  				    <tr>
	  					<th>ID</th>
	  					<th>Skill</th>
	  					<th>Percentage</th>
	  					<th>Status</th>
	  					<th class="text-center">Action</th>
  					</tr>
  				</thead>
  				<tbody>
  					<?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
  					   <tr>
  					   	  <td><?php echo e($skill->id); ?></td>
  					   	  <td><?php echo e($skill->skill); ?></td>
  					   	  <td><?php echo e($skill->percentage); ?></td>
  					   	  <td> <?php echo e($skill->viewed == true ? 'Viewed' : 'Hidden'); ?></td>
  					   	  <td class="text-center">
  					   	  	<a href="" class="btn btn-xs">
  					   	  		<i class="fa fa-eye fa-fw"></i>
  					   	  	</a>

  					   	  	<a href="" class="btn btn-xs">
  					   	  		<i class="fa fa-edit fa-fw"></i>
  					   	  	</a>

  					   	  	<a href="" class="btn btn-xs">
  					   	  		<i class="fa fa-trash fa-fw"></i>
  					   	  	</a>
  					   	  </td>
  					   </tr>
  					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  				</tbody>
  			</table>
  		</div>
  	</div>

    <div class="col-md-4">
      <div class="well">
        <h2 class="text-center">Add Skill</h2>
        <?php echo e(Form::open(['class' => 'form'])); ?>

           <?php echo e(Form::label('skill', 'Skill')); ?>

           <?php echo e(Form::text('skill', null, ['class' => 'form-control', 'placeholder' => 'skill'])); ?>


           <?php echo e(Form::label('percentage', 'Percentage')); ?>

           <input type="range" name="percentage" min="0" max="100" value="0">
           
           <?php echo e(Form::label('viewed', 'Visability')); ?>

           <?php echo e(Form::select('viewed', ['Viewed', 'Hidden'], null, ['class' => 'form-control', 'placeholder' => 'Visability'])); ?>

           <?php echo e(Form::submit('Add', ['class' => 'btn btn-spec btn-block'])); ?>

        <?php echo e(Form::close()); ?>

      </div>
      <p class="text-center"><b>Only 7 skill will be visable on frontend</b></p>
    </div>

  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>