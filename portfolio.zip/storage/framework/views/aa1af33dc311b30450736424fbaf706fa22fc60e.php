<?php $__env->startSection('styles'); ?>
   <?php $__env->startSection('styles'); ?>
   <?php echo Html::style('css/admin/login.css'); ?>

   <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
           <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-default">
                  <div class="panel-heading">
                    <h1 class="text-center reset-email">Reset Password</h1>
                  </div> 
                  <div class="panel-body"> 
                    <?php echo Form::open(['url' => '/admin/password/reset', 'method' => 'POST', 'class' => 'form']); ?>

        
                        <?php echo e(Form::hidden('token', $token)); ?>

                 
                        <?php echo e(Form::label('email', 'Email')); ?>

                        <?php echo e(Form::text('email', $email, ['class' => 'form-control', 'placeholder' => 'Your Email '])); ?>


                        <?php echo e(Form::label('password', 'New Password')); ?>

                        <?php echo e(Form::password('password', ['class' => 'form-control'])); ?>


                        <?php echo e(Form::label('password_confirmation', 'Confirm Password')); ?>

                        <?php echo e(Form::password('password_confirmation', ['class' => 'form-control'])); ?>

                        
                        <?php echo e(Form::submit('Reset Password', ['class' => 'btn btn-success'])); ?>

                    
                    <?php echo Form::close(); ?>

                  </div>
                </div>
           </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>