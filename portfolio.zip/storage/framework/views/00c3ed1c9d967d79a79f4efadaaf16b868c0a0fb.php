<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Amr El-Mahdy | <?php echo $__env->yieldContent('title'); ?> </title>

<!-- Bootstrap -->
<?php echo Html::style('css/common/app.css'); ?>

<?php echo Html::style('css/common/font-awesome.css'); ?>

<?php echo Html::style('css/frontend/main.css'); ?>

<?php echo Html::style('css/frontend/media.css'); ?>

<?php echo $__env->yieldContent('styles'); ?>

<?php echo $__env->yieldContent('extrastyles'); ?>
