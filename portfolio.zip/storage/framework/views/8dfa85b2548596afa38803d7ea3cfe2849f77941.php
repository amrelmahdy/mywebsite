<!DOCTYPE html>
<html lang="en">
  <head>

    <?php echo $__env->make('includes.admin.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
  </head>

  <body>  
     <?php if(count($errors) > 0): ?>
         <div class="error-info">
         	  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
         	    <?php echo e($error); ?>

         	  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          </div>
     <?php endif; ?>

     <?php echo $__env->yieldContent('content'); ?>
      
     <?php echo $__env->make('includes.admin.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </body>
</html>