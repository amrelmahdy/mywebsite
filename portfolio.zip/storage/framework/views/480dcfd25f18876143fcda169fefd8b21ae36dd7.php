<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Admin Area | <?php echo $__env->yieldContent('title'); ?> </title>

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">

<!-- Bootstrap -->
<?php echo Html::style('css/common/app.css'); ?>

<?php echo Html::style('css/common/font-awesome.css'); ?>

<?php echo Html::style('css/admin/simple-sidebar.css'); ?>

<?php echo Html::style('css/admin/navbar.css'); ?>

<?php echo Html::style('css/admin/main.css'); ?>


<?php echo $__env->yieldContent('styles'); ?>

<?php echo $__env->yieldContent('extrastyles'); ?>
