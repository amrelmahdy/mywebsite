<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', 'PagesController@index')->name('home');


// Admin Authentication

Route::group(['prefix' => 'admin'], function(){
	Route::get('/login', [
		'uses' => 'AdminAuth\LoginController@showLoginForm', 
		'as' => 'show-login-form'
	]);

	Route::post('login', [
		'uses' => 'AdminAuth\LoginController@login',
		'as'   => 'login', 
	]);

	Route::get('logout', 'AdminAuth\LoginController@logout')->name('logout');

   // Reset Password

	Route::get('password/reset', 'AdminAuth\ForgotPasswordController@showLinkRequestForm')->name('forgot-password');

	Route::post('password/email', 'AdminAuth\ForgotPasswordController@sendResetLinkEmail');

	Route::get('/password/reset/{token}', 'AdminAuth\ResetPasswordController@showResetForm');

	Route::post('/password/reset', 'AdminAuth\ResetPasswordController@reset');
  

	Route::get('/', 'AdminController@index')->name('admin-home');



    Route::get('/skills', 'SkillsController@index')->name('skills');


    // Portfolio

    Route::get('/portfolio', 'PortfolioController@index')->name('portfolio');
    
    Route::get('/portfolio/create', [
    	'uses' => 'PortfolioController@create',
    	'as'   => 'portfolio.create',
    ]);

    Route::post('/portfolio', [
    	'uses' => 'PortfolioController@store',
    	'as'   => 'portfolio.store',
    ]);

    Route::get('/portfolio/{sample}/edit', [
    	'uses' => 'PortfolioController@edit',
    	'as'   => 'portfolio.edit',
    ]);

    Route::put('/portfolio/{sample}', [
    	'uses' => 'PortfolioController@update',
    	'as'   => 'portfolio.update',
    ]);

    Route::delete('/portfolio/{sample}', [
    	'uses' => 'PortfolioController@detroy',
    	'as'   => 'portfolio.destroy',
    ]);

});
