<?php

namespace App;
use App\Sample;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    public function samples(){
    	return $this->hasMany('App\Sample');
    }
}
