<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Contact;
use App\Skill;
use App\Statistic;
use App\Experience;
use App\Education;
use App\Category;
use App\Sample;
use App\Social;

class PagesController extends Controller
{
   public function index(){
   	 // Return view Home

   	$contact_info = Contact::find(1);
   	$emails       = explode('/', $contact_info->email);
   	$skills       = Skill::all();
   	$statistics   = Statistic::find(1);
   	$experiences  = Experience::orderBy('created_at', 'desc')->get();
   	$educations   = Education::all();
   	$categories   = Category::all();
   	$samples      = Sample::all(); 
   	$social_media = Social::all();
   	
   	return view('frontend.index')->with(['contact_info' => $contact_info,
   		                                 'emails'       => $emails,
   	                                     'skills'       => $skills,
   	                                     'statistics'   => $statistics,
   	                                     'experiences'  => $experiences,
   	                                     'educations'   => $educations,
   	                                     'categories'   => $categories,
   	                                     'samples'      => $samples,
   	                                     'social_media' => $social_media ]);
   }
}
