<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Sample;
use App\Category;
use Image;
use Session;
use File;

class PortfolioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $samples = Sample::orderBy('id', 'desc')->get();
        return view('admin.portfolio.index')->withSamples($samples);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::all();
        $cats = [];
        foreach($categories as $category){
            $cats[$category->id] = $category->category;
        }
        return view('admin.portfolio.create')->withCats($cats);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'project_name' => 'required',
            'category_id'  => 'required', 
            'image'        => 'required',
            'link'         => 'required',
            'description'  => 'required'
        ]);

        // upload image sample 

        $image = $request->file('image');

        $imageName = time() . '.' . $image->getClientOriginalExtension();

        $imageLocation = public_path('images/portfolio/' . $imageName);

        Image::make($image)->resize(1350, 630)->save($imageLocation);

        $sample = new Sample();

        $sample->project_name = $request->project_name;
        $sample->category_id  = $request->category_id; 
        $sample->image        = $imageName;
        $sample->link         = $request->link;
        $sample->description  = $request->description;
        $sample->save();

        Session::flash('success', 'Sample added successfully');

        return redirect()->route('portfolio');
        
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $sample = Sample::find($id);
        $categories = Category::all();
        $cats = [];
        foreach($categories as $category){
            $cats[$category->id] = $category->category;
        }
        return view('admin.portfolio.edit')->with(['sample' => $sample, 'cats' => $cats ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $sample = Sample::find($id);

        $this->validate($request, [
            'project_name' => 'required',
            'category_id'  => 'required', 
            'image'        => 'image',
            'link'         => 'required',
            'description'  => 'required'
        ]);

        if($request->image){


            // upload image 
            $image = $request->file('image');

            $imageName = time() . '.' . $image->getClientOriginalExtension();

            $imageLocation = public_path('images/portfolio/' . $imageName);

            Image::make($image)->resize(1350, 630)->save($imageLocation);
            
            // delete old one 
            $old_image = $sample->image;
            File::delete(public_path('images/portfolio/' . $old_image));


        }
        // update and redirect
        $sample->project_name = $request->project_name;
        $sample->category_id  = $request->category_id; 
        
        if($request->image){
           $sample->image = $imageName;
        }
        
        $sample->link         = $request->link;
        $sample->description  = $request->description;
        $sample->update();

        Session::flash('success', 'Sample Updated successfully');

        return redirect()->route('portfolio');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
