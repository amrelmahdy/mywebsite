$(document).ready(function(){
	$('.success-msg, .error-msg').delay(3000).fadeOut(1000);
});